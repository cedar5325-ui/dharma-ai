import fs from "node:fs";
import path from "node:path";

const root = process.argv[2] ? path.resolve(process.argv[2]) : process.cwd();

function stamp() {
  const d = new Date();
  const z = v => String(v).padStart(2, "0");
  return `${d.getFullYear()}${z(d.getMonth()+1)}${z(d.getDate())}_${z(d.getHours())}${z(d.getMinutes())}${z(d.getSeconds())}`;
}

function patch(rel, originalName, fallbackText) {
  const file = path.join(root, ...rel.split("/"));
  if (!fs.existsSync(file)) throw new Error(`${rel} not found`);

  let s = fs.readFileSync(file, "utf8");
  const backup = `${file}.backup_${stamp()}`;
  fs.copyFileSync(file, backup);
  console.log(`Backup: ${backup}`);

  if (!s.includes('Suspense')) {
    if (s.includes('from "react";')) {
      s = s.replace(/import\s*\{\s*([^}]+)\s*\}\s*from\s*"react";/, (m, inside) => {
        const names = inside.split(",").map(x => x.trim()).filter(Boolean);
        if (!names.includes("Suspense")) names.unshift("Suspense");
        return `import { ${names.join(", ")} } from "react";`;
      });
    } else {
      const useClient = '"use client";';
      if (s.includes(useClient)) {
        s = s.replace(useClient, `${useClient}\n\nimport { Suspense } from "react";`);
      } else {
        s = `import { Suspense } from "react";\n` + s;
      }
    }
  }

  const oldSig = `export default function ${originalName}()`;
  const newName = `${originalName}Content`;
  if (s.includes(oldSig)) {
    s = s.replace(oldSig, `function ${newName}()`);
  } else if (!s.includes(`function ${newName}()`)) {
    throw new Error(`${rel}: function ${originalName} not found`);
  }

  if (!s.includes(`export default function ${originalName}PageWrapper()`)) {
    s += `\n\nexport default function ${originalName}PageWrapper() {\n` +
         `  return (\n` +
         `    <Suspense fallback={<main className="section white"><p>${fallbackText}</p></main>}>\n` +
         `      <${newName} />\n` +
         `    </Suspense>\n` +
         `  );\n` +
         `}\n`;
  }

  fs.writeFileSync(file, s, "utf8");
  console.log(`Patched: ${rel}`);
}

patch("src/app/payment/page.tsx", "PaymentPage", "결제정보를 불러오는 중입니다.");
patch("src/app/payment/success/page.tsx", "PaymentSuccess", "결제 결과를 확인하는 중입니다.");
patch("src/app/payment/fail/page.tsx", "PaymentFail", "결제 결과를 확인하는 중입니다.");

const next = path.join(root, ".next");
if (fs.existsSync(next)) {
  fs.rmSync(next, { recursive: true, force: true });
  console.log("Removed .next cache.");
}

console.log("");
console.log("Suspense fix completed.");
console.log("Next: npm.cmd run build");

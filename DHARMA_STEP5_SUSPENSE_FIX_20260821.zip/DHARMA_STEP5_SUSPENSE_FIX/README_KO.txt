DHARMA STEP 5 - Next.js useSearchParams Suspense fix

수정 대상:
- src/app/payment/page.tsx
- src/app/payment/success/page.tsx
- src/app/payment/fail/page.tsx

각 페이지의 useSearchParams 사용 컴포넌트를 Suspense 경계로 감쌉니다.
기존 결제 로직은 변경하지 않습니다.

실행:
node APPLY_STEP5_SUSPENSE_FIX.mjs "C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC"

그 다음:
npm.cmd run build

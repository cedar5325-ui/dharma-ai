DHARMA AI V4 - 관리자 로그인 시 다운로드 허용 패치
=====================================================

목적
----
기존 V3 PG/결제 정책은 그대로 유지하고,
현재 관리자 로그인 세션이 유효한 브라우저에서만 원문 다운로드를 허용합니다.

정책
----
1) 관리자 로그인 상태
   -> 다운로드 허용

2) 일반 사용자 + PG 승인 전
   -> 검색/상세 열람 가능
   -> 다운로드 차단

3) 일반 사용자 + PG 승인 후
   -> 기존 V3 로직 그대로
   -> 결제/구매 검증 완료 자료만 다운로드 허용

중요
----
- ADMIN_PASSWORD 값을 바꾸지 않습니다.
- DHARMA_PG_APPROVED 값을 바꾸지 않습니다.
- DHARMA_TEST_PURCHASE_ENABLED 값을 바꾸지 않습니다.
- 기존 구매/결제 검증 코드를 삭제하거나 대체하지 않습니다.
- 다운로드 API의 V3 PG 게이트 앞에 관리자 세션 확인만 추가합니다.
- 관리자 여부는 현재 /admin 접근이 기존 인증에 의해 허용되는지 서버에서 확인합니다.
  즉, 새로운 별도 인증번호나 별도 관리자 비밀번호를 만들지 않습니다.

적용
----
1. 압축을 푼 폴더를 DHARMA_AI_v4_RC 프로젝트 폴더 안에 둡니다.
2. RUN_PATCH_AUTO.cmd 실행
3. VS Code 터미널에서:
   npm.cmd run build
4. 빌드 성공 후:
   git add -- ":(literal)src/app/api/materials/[id]/download/route.ts"
   git commit -m "Allow downloads for authenticated admin"
   git push origin main
5. Vercel 최신 Production 배포가 Ready인지 확인합니다.

테스트
------
A. 일반 InPrivate/시크릿 창
   - /materials 검색 가능
   - 다운로드 차단

B. 관리자 브라우저
   - /admin-login 로그인
   - 같은 브라우저에서 /materials 이동
   - 다운로드 허용

C. 관리자 로그아웃 후
   - 다시 다운로드 차단

PG 승인 후
----------
DHARMA_PG_APPROVED=true로 전환해도 관리자 다운로드는 계속 허용됩니다.
일반 고객은 기존 결제/구매 검증을 통과한 자료만 다운로드됩니다.

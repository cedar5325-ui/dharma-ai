@echo off
setlocal
chcp 65001 >nul
set "PROJECT=%~dp0"
:findproject
if exist "%PROJECT%package.json" goto found
for %%I in ("%PROJECT%..") do set "PROJECT=%%~fI\"
if "%PROJECT%"=="%~d0\" goto notfound
goto findproject

:found
node "%~dp0VERIFY_ADMIN_LOGIN_DOWNLOAD_BYPASS_V4.mjs" --project "%PROJECT%"
echo.
pause
exit /b %errorlevel%

:notfound
echo Could not find package.json.
pause
exit /b 1

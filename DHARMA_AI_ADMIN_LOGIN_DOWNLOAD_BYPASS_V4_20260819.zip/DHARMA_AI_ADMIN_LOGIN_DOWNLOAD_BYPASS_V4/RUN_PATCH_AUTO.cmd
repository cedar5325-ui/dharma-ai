@echo off
setlocal
chcp 65001 >nul
echo.
echo DHARMA AI V4 - Admin login download bypass only
echo.

set "PROJECT=%~dp0"
:findproject
if exist "%PROJECT%package.json" goto found
for %%I in ("%PROJECT%..") do set "PROJECT=%%~fI\"
if "%PROJECT%"=="%~d0\" goto notfound
goto findproject

:found
echo Project: %PROJECT%
node "%~dp0APPLY_ADMIN_LOGIN_DOWNLOAD_BYPASS_V4.mjs" --project "%PROJECT%"
echo.
if errorlevel 1 (
  echo Patch failed. No GitHub push should be done.
  pause
  exit /b 1
)
echo Patch finished. Now run npm.cmd run build in VS Code.
pause
exit /b 0

:notfound
echo Could not find package.json. Put this extracted patch folder inside the DHARMA project folder.
pause
exit /b 1

import fs from "node:fs";
import path from "node:path";

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === "--project" && argv[i + 1]) {
      out.project = argv[i + 1];
      i += 1;
    }
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));
const root = path.resolve(args.project || process.cwd());
const route = path.join(root, "src", "app", "api", "materials", "[id]", "download", "route.ts");

if (!fs.existsSync(route)) {
  console.error(`Missing: ${route}`);
  process.exit(1);
}

const src = fs.readFileSync(route, "utf8");

const checks = [
  ["V4 admin marker", src.includes("DHARMA_ADMIN_LOGIN_DOWNLOAD_BYPASS_V4")],
  ["Admin session verifier helper", src.includes("hasDharmaAdminDownloadAccess")],
  ["Existing V3 marker retained", src.includes("DHARMA_PG_PAYMENT_DOWNLOAD_POLICY")],
  ["Existing PG gate retained", src.includes("enforcePgApprovalBeforeDownload")],
  ["Admin bypass wraps PG gate", /if\s*\(\s*!dharmaAdminDownloadAllowed\s*\)\s*\{[\s\S]*enforcePgApprovalBeforeDownload/.test(src)],
];

let ok = true;
for (const [name, passed] of checks) {
  console.log(`${passed ? "OK" : "FAIL"} - ${name}`);
  if (!passed) ok = false;
}

if (!ok) process.exit(1);

console.log("");
console.log("Static verification passed.");
console.log("Run npm.cmd run build next.");

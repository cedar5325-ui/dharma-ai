import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const V4_MARKER = "DHARMA_ADMIN_LOGIN_DOWNLOAD_BYPASS_V4";
const V3_MARKER = "DHARMA_PG_PAYMENT_DOWNLOAD_POLICY";

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === "--project" && argv[i + 1]) {
      out.project = argv[i + 1];
      i += 1;
    }
  }
  return out;
}

function locateProjectRoot(candidate) {
  const starts = [candidate, process.cwd(), SCRIPT_DIR].filter(Boolean);
  for (const start of starts) {
    let current = path.resolve(start);
    for (let depth = 0; depth < 10; depth += 1) {
      if (fs.existsSync(path.join(current, "package.json"))) return current;
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
  }
  throw new Error("Could not locate the DHARMA project folder containing package.json.");
}

function stamp() {
  const d = new Date();
  const p = (v) => String(v).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function backup(filePath) {
  const backupPath = `${filePath}.backup_${stamp()}`;
  fs.copyFileSync(filePath, backupPath);
  console.log(`Backup: ${backupPath}`);
}

function writeText(filePath, content) {
  fs.writeFileSync(filePath, content.replace(/\r?\n/g, "\r\n"), "utf8");
}

function insertHelperAfterImports(source) {
  if (source.includes(`function hasDharmaAdminDownloadAccess`)) return source;

  const helper = `

async function hasDharmaAdminDownloadAccess(request) {
  const cookieHeader = request.headers.get("cookie") ?? "";
  if (!cookieHeader) return false;

  try {
    const adminCheck = await fetch(new URL("/admin", request.url), {
      method: "GET",
      headers: {
        cookie: cookieHeader,
      },
      redirect: "manual",
      cache: "no-store",
    });

    // Existing /admin authentication remains the source of truth.
    // Authenticated admin => normal 2xx page.
    // Unauthenticated visitor => redirect to /admin-login.
    return adminCheck.status >= 200 && adminCheck.status < 300;
  } catch {
    // Fail closed: if admin verification cannot be confirmed,
    // continue through the normal PG/payment policy.
    return false;
  }
}
`;

  const importRegex = /^import[\s\S]*?from\s+["'][^"']+["'];?\s*$/gm;
  let lastEnd = 0;
  for (const match of source.matchAll(importRegex)) {
    lastEnd = match.index + match[0].length;
  }

  if (lastEnd > 0) {
    return source.slice(0, lastEnd) + helper + source.slice(lastEnd);
  }
  return helper.trimStart() + "\n" + source;
}

function patchDownloadRoute(routePath) {
  const original = fs.readFileSync(routePath, "utf8");

  if (original.includes(V4_MARKER)) {
    console.log("V4 admin-login download bypass is already installed.");
    return false;
  }

  if (!original.includes(V3_MARKER) || !original.includes("enforcePgApprovalBeforeDownload")) {
    throw new Error(
      "The V3 PG/payment policy marker was not found. Stop here so the existing payment policy is not altered accidentally."
    );
  }

  const gateRegex =
    /(\s*)\/\/\s*DHARMA_PG_PAYMENT_DOWNLOAD_POLICY[^\r\n]*\r?\n\s*const\s+dharmaPgPolicyBlock\s*=\s*enforcePgApprovalBeforeDownload\(([^)]+)\);\r?\n\s*if\s*\(\s*dharmaPgPolicyBlock\s*\)\s*return\s+dharmaPgPolicyBlock;?/m;

  const match = gateRegex.exec(original);
  if (!match) {
    throw new Error(
      "The exact V3 PG guard block could not be identified. No files were changed."
    );
  }

  const indent = match[1] || "  ";
  const requestExpr = match[2].trim();

  const replacement =
`${indent}// ${V4_MARKER}
${indent}const dharmaAdminDownloadAllowed = await hasDharmaAdminDownloadAccess(${requestExpr});
${indent}if (!dharmaAdminDownloadAllowed) {
${indent}  // ${V3_MARKER}
${indent}  const dharmaPgPolicyBlock = enforcePgApprovalBeforeDownload(${requestExpr});
${indent}  if (dharmaPgPolicyBlock) return dharmaPgPolicyBlock;
${indent}}`;

  let updated = original.replace(gateRegex, replacement);
  updated = insertHelperAfterImports(updated);

  // Safety checks before writing.
  if (!updated.includes(V4_MARKER)) throw new Error("V4 marker insertion failed.");
  if (!updated.includes(V3_MARKER)) throw new Error("V3 marker disappeared; refusing to write.");
  if (!updated.includes("enforcePgApprovalBeforeDownload")) {
    throw new Error("Existing PG/payment gate disappeared; refusing to write.");
  }

  backup(routePath);
  writeText(routePath, updated);
  console.log(`Patched: ${routePath}`);
  return true;
}

function removeNextCache(projectRoot) {
  const nextDir = path.join(projectRoot, ".next");
  if (fs.existsSync(nextDir)) {
    fs.rmSync(nextDir, { recursive: true, force: true });
    console.log("Removed .next cache.");
  }
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const projectRoot = locateProjectRoot(args.project);
  const routePath = path.join(
    projectRoot, "src", "app", "api", "materials", "[id]", "download", "route.ts"
  );

  console.log("");
  console.log("DHARMA AI V4 - Admin login download bypass only");
  console.log(`Project: ${projectRoot}`);
  console.log("");

  if (!fs.existsSync(routePath)) {
    throw new Error(`Download route not found: ${routePath}`);
  }

  patchDownloadRoute(routePath);
  removeNextCache(projectRoot);

  console.log("");
  console.log("Patch completed.");
  console.log("- Admin session: download allowed.");
  console.log("- Non-admin: existing V3 PG/payment policy is unchanged.");
  console.log("- Before PG approval: ordinary users remain blocked.");
  console.log("- After PG approval: ordinary users still need a verified purchase.");
  console.log("");
  console.log("Next:");
  console.log(`cd "${projectRoot}"`);
  console.log("npm.cmd run build");
}

try {
  main();
} catch (error) {
  console.error("");
  console.error(error instanceof Error ? `ERROR: ${error.message}` : `ERROR: ${String(error)}`);
  process.exitCode = 1;
}

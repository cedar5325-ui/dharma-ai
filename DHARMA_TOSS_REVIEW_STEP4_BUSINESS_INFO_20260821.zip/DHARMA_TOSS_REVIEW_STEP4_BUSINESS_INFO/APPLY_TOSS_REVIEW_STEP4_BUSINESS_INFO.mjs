import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--project" && argv[i + 1]) out.project = argv[++i];
  }
  return out;
}

function findRoot(candidate) {
  for (const start of [candidate, process.cwd(), SCRIPT_DIR].filter(Boolean)) {
    let p = path.resolve(start);
    for (let i = 0; i < 10; i++) {
      if (fs.existsSync(path.join(p, "package.json"))) return p;
      const parent = path.dirname(p);
      if (parent === p) break;
      p = parent;
    }
  }
  throw new Error("DHARMA project root not found.");
}

function stamp() {
  const d = new Date();
  const z = v => String(v).padStart(2, "0");
  return `${d.getFullYear()}${z(d.getMonth()+1)}${z(d.getDate())}_${z(d.getHours())}${z(d.getMinutes())}${z(d.getSeconds())}`;
}

function backup(file) {
  if (!fs.existsSync(file)) return;
  const dest = `${file}.backup_${stamp()}`;
  fs.copyFileSync(file, dest);
  console.log(`Backup: ${dest}`);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const root = findRoot(args.project);

  const libDir = path.join(root, "src", "lib");
  const compDir = path.join(root, "src", "components");
  const businessTarget = path.join(libDir, "dharmaBusiness.ts");
  const footerTarget = path.join(compDir, "DharmaBusinessFooter.tsx");

  fs.mkdirSync(libDir, { recursive: true });
  fs.mkdirSync(compDir, { recursive: true });

  backup(businessTarget);
  backup(footerTarget);

  fs.copyFileSync(path.join(SCRIPT_DIR, "dharmaBusiness.ts"), businessTarget);
  fs.copyFileSync(path.join(SCRIPT_DIR, "DharmaBusinessFooter.tsx"), footerTarget);

  console.log(`Patched: ${businessTarget}`);
  console.log(`Patched: ${footerTarget}`);

  const nextDir = path.join(root, ".next");
  if (fs.existsSync(nextDir)) {
    fs.rmSync(nextDir, { recursive: true, force: true });
    console.log("Removed .next cache.");
  }

  console.log("");
  console.log("STEP 4 business information patch completed.");
  console.log("- Legal business information matches the provided registration certificate.");
  console.log("- Brand name remains DHARMA AI separately.");
  console.log("- No PG/payment/download API files were changed.");
  console.log("Next: npm.cmd run build");
}

try { main(); }
catch (e) {
  console.error(`ERROR: ${e instanceof Error ? e.message : String(e)}`);
  process.exitCode = 1;
}

DHARMA Toss Payments 심사 준비 - STEP 4 사업자정보

사업자등록증 기준
- 상호명: 다르마 교육연구소
- 대표자명: 강기만
- 사업자등록번호: 257-90-02380
- 사업장 주소: 전남광주통합특별시 남구 봉선로 76, 102동 604호(주월동, 이지 더원 아파트 1단지)
- 업태: 교육서비스업, 정보통신업
- 종목: 교육관련 자문 및 평가업, 포털 및 기타 인터넷 정보 매개 서비스업

연락처
- 고객센터: 010-5641-1225
- 이메일: cedar5325@gmail.com

브랜드명
- 다르마(DHARMA) AI
- 브랜드명과 법적 사업자명을 Footer에서 구분하여 표시합니다.

통신판매업 신고번호는 실제 발급 전이므로 임의값을 표시하지 않습니다.

적용
1. ZIP을 프로젝트 폴더에 저장하고 압축 해제
2. PowerShell:
$project = "C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC"
$script = Get-ChildItem -Path $project -Filter "APPLY_TOSS_REVIEW_STEP4_BUSINESS_INFO.mjs" -File -Recurse | Select-Object -First 1
node $script.FullName --project $project

3. npm.cmd run build
4. npm.cmd run dev
5. 홈페이지 /pricing /refund /terms /privacy 하단 Footer 확인

성공 후
git add src/lib/dharmaBusiness.ts
git add src/components/DharmaBusinessFooter.tsx
git commit -m "Update business information for Toss review"
git push origin main

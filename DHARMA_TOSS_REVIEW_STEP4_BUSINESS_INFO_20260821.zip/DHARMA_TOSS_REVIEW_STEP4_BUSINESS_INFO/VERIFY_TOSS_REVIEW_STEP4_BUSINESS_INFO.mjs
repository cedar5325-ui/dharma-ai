import fs from "node:fs";
import path from "node:path";

const i = process.argv.indexOf("--project");
const root = path.resolve(i >= 0 ? process.argv[i+1] : process.cwd());

const business = path.join(root, "src", "lib", "dharmaBusiness.ts");
const footer = path.join(root, "src", "components", "DharmaBusinessFooter.tsx");

const b = fs.existsSync(business) ? fs.readFileSync(business, "utf8") : "";
const f = fs.existsSync(footer) ? fs.readFileSync(footer, "utf8") : "";

const checks = [
  ["business module", fs.existsSync(business)],
  ["footer module", fs.existsSync(footer)],
  ["legal name", b.includes("다르마 교육연구소")],
  ["representative", b.includes("강기만")],
  ["business number", b.includes("257-90-02380")],
  ["full address", b.includes("전남광주통합특별시 남구 봉선로 76, 102동 604호")],
  ["phone", b.includes("010-5641-1225")],
  ["email", b.includes("cedar5325@gmail.com")],
  ["footer marker", f.includes("DHARMA_TOSS_REVIEW_STEP4_BUSINESS_INFO")],
  ["refund link", f.includes('href="/refund"')],
];

let ok = true;
for (const [name, pass] of checks) {
  console.log(`${pass ? "OK" : "FAIL"} - ${name}`);
  if (!pass) ok = false;
}
if (!ok) process.exit(1);
console.log("");
console.log("STEP 4 verification passed.");

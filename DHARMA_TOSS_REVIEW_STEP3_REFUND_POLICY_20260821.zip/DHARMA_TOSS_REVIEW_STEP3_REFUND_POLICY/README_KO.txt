DHARMA Toss Payments 심사 준비 - STEP 3 환불정책

반영 내용
- 결제 후 다운로드 전 환불 요청 기준
- 다운로드 후 단순 변심 환불 제한 가능 안내
- 파일 오류/상품 설명과 현저한 차이
- 중복결제/오결제
- 결제일로부터 30일 제공기간
- 환불 승인 후 결제수단별 처리기간
- 고객센터/이메일
- 관계 법령 우선 적용 문구

이 패치는 /refund 페이지 한 파일만 수정합니다.
결제 API, 구매 API, 다운로드 API는 수정하지 않습니다.

적용:
$project = "C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC"
$script = Get-ChildItem -Path $project -Filter "APPLY_TOSS_REVIEW_STEP3_REFUND_POLICY.mjs" -File -Recurse | Select-Object -First 1
node $script.FullName --project $project

그다음:
npm.cmd run build
npm.cmd run dev

확인:
http://localhost:3000/refund

성공 후:
git add src/app/refund/page.tsx
git commit -m "Update refund policy for Toss review"
git push origin main

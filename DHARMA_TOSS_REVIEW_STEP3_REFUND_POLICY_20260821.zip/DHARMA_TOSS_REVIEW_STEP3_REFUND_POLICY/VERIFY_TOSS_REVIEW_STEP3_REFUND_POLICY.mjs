import fs from "node:fs";
import path from "node:path";

const i = process.argv.indexOf("--project");
const root = path.resolve(i >= 0 ? process.argv[i+1] : process.cwd());
const file = path.join(root, "src", "app", "refund", "page.tsx");

if (!fs.existsSync(file)) {
  console.error("FAIL - refund page missing");
  process.exit(1);
}

const s = fs.readFileSync(file, "utf8");
const checks = [
  ["step 3 marker", s.includes("DHARMA_TOSS_REVIEW_STEP3_REFUND_POLICY")],
  ["30-day period", s.includes("결제일로부터 30일")],
  ["before download", s.includes("결제 후 다운로드 전")],
  ["after download", s.includes("원문 파일 다운로드 후")],
  ["duplicate payment", s.includes("중복 결제")],
  ["file error", s.includes("파일 오류")],
  ["customer phone", s.includes("010-5641-1225")],
  ["customer email", s.includes("cedar5325@gmail.com")],
];

let ok = true;
for (const [name, pass] of checks) {
  console.log(`${pass ? "OK" : "FAIL"} - ${name}`);
  if (!pass) ok = false;
}
if (!ok) process.exit(1);
console.log("");
console.log("STEP 3 verification passed.");

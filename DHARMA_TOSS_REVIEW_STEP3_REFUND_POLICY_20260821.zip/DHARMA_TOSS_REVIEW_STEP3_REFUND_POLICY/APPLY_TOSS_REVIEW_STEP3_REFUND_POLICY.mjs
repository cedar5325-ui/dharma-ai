import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const MARKER = "DHARMA_TOSS_REVIEW_STEP3_REFUND_POLICY";

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--project" && argv[i + 1]) out.project = argv[++i];
  }
  return out;
}

function findRoot(candidate) {
  for (const start of [candidate, process.cwd(), SCRIPT_DIR].filter(Boolean)) {
    let p = path.resolve(start);
    for (let i = 0; i < 10; i++) {
      if (fs.existsSync(path.join(p, "package.json"))) return p;
      const parent = path.dirname(p);
      if (parent === p) break;
      p = parent;
    }
  }
  throw new Error("DHARMA project root not found.");
}

function stamp() {
  const d = new Date();
  const z = v => String(v).padStart(2, "0");
  return `${d.getFullYear()}${z(d.getMonth()+1)}${z(d.getDate())}_${z(d.getHours())}${z(d.getMinutes())}${z(d.getSeconds())}`;
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const root = findRoot(args.project);
  const target = path.join(root, "src", "app", "refund", "page.tsx");
  const source = path.join(SCRIPT_DIR, "refund.page.tsx");

  if (!fs.existsSync(target)) {
    throw new Error(`Missing refund page: ${target}`);
  }

  const current = fs.readFileSync(target, "utf8");
  const backup = `${target}.backup_${stamp()}`;
  fs.copyFileSync(target, backup);
  console.log(`Backup: ${backup}`);

  const next = fs.readFileSync(source, "utf8");
  if (!next.includes(MARKER)) {
    throw new Error("Step 3 marker missing in source template.");
  }

  fs.writeFileSync(target, next, "utf8");
  console.log(`Patched: ${target}`);

  const nextDir = path.join(root, ".next");
  if (fs.existsSync(nextDir)) {
    fs.rmSync(nextDir, { recursive: true, force: true });
    console.log("Removed .next cache.");
  }

  console.log("");
  console.log("STEP 3 refund policy patch completed.");
  console.log("- 결제/다운로드 API는 수정하지 않았습니다.");
  console.log("- /refund 페이지 문구와 구조만 정리했습니다.");
  console.log("Next: npm.cmd run build");
}

try { main(); }
catch (e) {
  console.error(`ERROR: ${e instanceof Error ? e.message : String(e)}`);
  process.exitCode = 1;
}

import fs from "node:fs";
import path from "node:path";

const root = path.resolve(process.argv[2] || process.cwd());
const businessFile = path.join(root, "src", "lib", "dharmaBusiness.ts");
const footerFile = path.join(root, "src", "components", "DharmaBusinessFooter.tsx");

if (!fs.existsSync(businessFile)) throw new Error("dharmaBusiness.ts not found");
if (!fs.existsSync(footerFile)) throw new Error("DharmaBusinessFooter.tsx not found");

let business = fs.readFileSync(businessFile, "utf8");
business = business.replace(/ecommerceRegistrationNumber\s*:\s*"[^"]*"/, 'ecommerceRegistrationNumber: "제2026-광주남구-0292호"');
fs.writeFileSync(businessFile, business, "utf8");

let footer = fs.readFileSync(footerFile, "utf8");
if (!footer.includes("통신판매업 신고번호")) {
  const anchor = `<div>\n            <strong>사업자등록번호</strong> {DHARMA_BUSINESS.businessNumber}\n          </div>`;
  const insert = `${anchor}\n          <div>\n            <strong>통신판매업 신고번호</strong>{" "}\n            {DHARMA_BUSINESS.ecommerceRegistrationNumber}\n          </div>`;
  if (!footer.includes(anchor)) throw new Error("business number footer block not found");
  footer = footer.replace(anchor, insert);
  fs.writeFileSync(footerFile, footer, "utf8");
}

console.log("Patched: src/lib/dharmaBusiness.ts");
console.log("Patched: src/components/DharmaBusinessFooter.tsx");
console.log("Next: npm.cmd run build");

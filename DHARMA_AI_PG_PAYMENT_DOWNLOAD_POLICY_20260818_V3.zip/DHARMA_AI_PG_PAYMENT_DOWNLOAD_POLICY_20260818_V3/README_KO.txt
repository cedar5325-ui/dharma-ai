﻿DHARMA AI — PG 승인 전 전체 다운로드 차단 / 승인 후 결제 완료자만 다운로드 V3

[최종 운영정책]

1. PG사 승인 전
   - 모바일과 PC 모두 자료 검색 가능
   - 과목 필터와 상세페이지 열람 가능
   - 원문 파일 다운로드는 모든 사용자에게 차단
   - 운영자 인증번호 우회도 사용하지 않음

2. PG사 승인 후
   - DHARMA_PG_APPROVED=true로 변경
   - 사전 차단만 해제
   - 기존 다운로드 API의 결제·구매 완료 검증은 그대로 실행
   - 결제가 완료되고 구매내역이 확인된 자료만 모바일·PC에서 다운로드
   - 미결제 사용자는 다운로드 불가

3. 테스트 구매 완료 기능
   - 운영 환경에서는 항상 차단
   - 로컬에서도 DHARMA_TEST_PURCHASE_ENABLED=true로 명시한 경우에만 사용
   - Vercel Production에는 반드시 false 유지

────────────────────────────────────────
중요: 지금 열려 있는 V2 인증번호 입력 창
────────────────────────────────────────

기존 V2 창이 아래 문구에서 기다리고 있다면 번호를 입력하지 마세요.

Enter owner download code (8-12 digits):

창 오른쪽 위 X를 눌러 닫으세요.
운영자 인증번호 방식은 이번 최종정책에서 사용하지 않습니다.

────────────────────────────────────────
V3 적용
────────────────────────────────────────

1. ZIP을 다음 프로젝트 폴더에 저장합니다.

C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC

2. ZIP을 압축 해제합니다.

3. 압축을 푼 폴더에서 다음 파일을 더블클릭합니다.

RUN_PATCH_AUTO.cmd

이 패치는 인증번호를 묻지 않습니다.

4. 패치 완료 후 VS Code 터미널에서 실행합니다.

cd "C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC"
npm.cmd run build
npm.cmd run dev

5. 정책 상태 확인

http://localhost:3000/api/system/download-policy

PG 승인 전 정상 예시:

{
  "pgApproved": false,
  "downloadMode": "all-downloads-blocked",
  "paymentRequiredAfterPgApproval": true,
  "testPurchaseEnabled": false
}

────────────────────────────────────────
로컬 검증
────────────────────────────────────────

A. PG 승인 전

.env.local:

DHARMA_PG_APPROVED=false
DHARMA_TEST_PURCHASE_ENABLED=false

일반 브라우저와 InPrivate 창에서 모두 확인합니다.

http://localhost:3000/materials

정상 결과:
- 검색 가능
- 상세 열람 가능
- 다운로드 클릭 시 403 차단
- PC와 모바일 모두 동일
- 이전 운영자 인증 쿠키가 있어도 다운로드 불가

B. PG 승인 후 테스트는 실제 승인 이후에만 진행

.env.local 및 Vercel:

DHARMA_PG_APPROVED=true
DHARMA_TEST_PURCHASE_ENABLED=false

재시작 또는 재배포 후 다음 두 경우를 반드시 확인합니다.

1) 미결제 계정·브라우저
   → 다운로드 불가

2) 실제 결제 완료 및 구매기록 확인 계정
   → 해당 구매자료만 다운로드 가능

이 패치는 PG 승인 후 다운로드를 자동 허용하지 않습니다.
PG 승인 차단을 해제한 뒤 기존 결제·구매 검증 코드로 계속 진행합니다.

────────────────────────────────────────
Vercel 환경변수
────────────────────────────────────────

PG 승인 전:

DHARMA_PG_APPROVED=false
DHARMA_TEST_PURCHASE_ENABLED=false

PG 승인 후:

DHARMA_PG_APPROVED=true
DHARMA_TEST_PURCHASE_ENABLED=false

환경변수 변경 후 반드시 새 배포 또는 Redeploy를 실행하세요.

기존 V2에서 아래 환경변수를 Vercel에 넣었다면 삭제합니다.

DHARMA_PUBLIC_DOWNLOAD_ENABLED
DHARMA_OWNER_DOWNLOAD_CODE
DHARMA_OWNER_DOWNLOAD_TOKEN_SECRET
DHARMA_OWNER_DOWNLOAD_SESSION_HOURS

────────────────────────────────────────
GitHub에 올릴 파일
────────────────────────────────────────

git add .gitignore
git add src/lib/pg-download-policy.ts
git add src/app/api/system/download-policy/route.ts
git add -- ":(literal)src/app/api/materials/[id]/download/route.ts"

테스트 구매 경로가 프로젝트에 존재하면:

git add -- ":(literal)src/app/api/purchases/test-complete/route.ts"

git commit -m "Enforce PG approval and paid-download policy"
git push origin main

.env.local은 GitHub에 올리지 않습니다.

────────────────────────────────────────
검증
────────────────────────────────────────

압축 해제 폴더에서:

RUN_VERIFY_AUTO.cmd

또는:

node ".\VERIFY_PG_PAYMENT_DOWNLOAD_POLICY_V3.mjs" --project "C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC" --build

검증 결과의 다음 항목이 PASS여야 합니다.

- PG policy guard file
- Policy status API
- PG route import
- PG route marker
- Pre-approval mode is fail-closed
- Test purchase is disabled
- Old owner/mobile gate removed

"Existing payment/purchase verification evidence"가 FAIL 또는 경고라면
DHARMA_PG_APPROVED=true로 바꾸지 말고 다운로드 API의 구매 검증 코드를 먼저 점검해야 합니다.

────────────────────────────────────────
보안 기준
────────────────────────────────────────

- Supabase 원문 버킷은 public=false로 유지
- 원본 public URL을 고객 페이지에 직접 노출하지 않음
- 다운로드는 /api/materials/[id]/download를 통해서만 제공
- Production의 test-complete 기능은 비활성화
- 결제 승인 결과는 서버에서 Toss Payments API와 금액·주문번호를 검증
- 구매기록의 사용자·자료 ID·결제상태를 서버에서 다시 검증

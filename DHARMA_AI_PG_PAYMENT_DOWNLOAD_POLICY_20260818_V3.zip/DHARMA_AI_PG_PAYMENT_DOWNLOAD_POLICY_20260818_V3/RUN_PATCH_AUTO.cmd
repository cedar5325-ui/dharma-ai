﻿@echo off
setlocal
chcp 65001 >nul
echo.
echo DHARMA AI PG/payment download policy patch V3
echo.
node "%~dp0APPLY_PG_PAYMENT_DOWNLOAD_POLICY_V3.mjs"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%EXIT_CODE%"=="0" (
  echo Patch failed. Review the ERROR message above.
) else (
  echo Patch completed. Open VS Code and run:
  echo npm.cmd run build
  echo npm.cmd run dev
)
echo.
pause
exit /b %EXIT_CODE%

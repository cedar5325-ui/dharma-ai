import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));

function parseArgs(argv) {
  const result = { build: false };
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === "--project" && argv[index + 1]) {
      result.project = argv[index + 1];
      index += 1;
    } else if (argv[index] === "--build") {
      result.build = true;
    }
  }
  return result;
}

function locateProjectRoot(candidate) {
  for (const start of [candidate, process.cwd(), SCRIPT_DIR].filter(Boolean)) {
    let current = path.resolve(start);
    for (let depth = 0; depth < 10; depth += 1) {
      if (fs.existsSync(path.join(current, "package.json"))) return current;
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
  }
  throw new Error("Could not locate the project folder.");
}

function envValue(source, name) {
  const match = source.match(
    new RegExp(`^\\s*${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*=\\s*(.*)$`, "m"),
  );
  return match?.[1]?.trim() ?? "";
}

function count(source, needle) {
  return source.split(needle).length - 1;
}

function check(label, passed, detail = "") {
  const mark = passed ? "PASS" : "FAIL";
  console.log(`${mark.padEnd(4)}  ${label}${detail ? ` - ${detail}` : ""}`);
  return passed;
}

function paymentEvidence(source) {
  const patterns = [
    /\bpurchase\b/i,
    /\bpurchases\b/i,
    /\bpayment\b/i,
    /\bpaid\b/i,
    /payment[_-]?key/i,
    /purchase[_-]?token/i,
    /order[_-]?id/i,
    /dharma_purchases/i,
    /결제/,
    /구매/,
  ];
  return patterns.some((pattern) => pattern.test(source));
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const projectRoot = locateProjectRoot(args.project);

  const envPath = path.join(projectRoot, ".env.local");
  const guardPath = path.join(projectRoot, "src/lib/pg-download-policy.ts");
  const statusPath = path.join(
    projectRoot,
    "src/app/api/system/download-policy/route.ts",
  );
  const routePath = path.join(
    projectRoot,
    "src/app/api/materials/[id]/download/route.ts",
  );
  const testRoutePath = path.join(
    projectRoot,
    "src/app/api/purchases/test-complete/route.ts",
  );

  const envSource = fs.existsSync(envPath) ? fs.readFileSync(envPath, "utf8") : "";
  const routeSource = fs.existsSync(routePath)
    ? fs.readFileSync(routePath, "utf8")
    : "";
  const testRouteSource = fs.existsSync(testRoutePath)
    ? fs.readFileSync(testRoutePath, "utf8")
    : "";

  console.log("");
  console.log("DHARMA PG/payment download policy verification V3");
  console.log(`Project: ${projectRoot}`);
  console.log("");

  const requiredChecks = [];
  requiredChecks.push(
    check("PG policy guard file", fs.existsSync(guardPath)),
  );
  requiredChecks.push(
    check("Policy status API", fs.existsSync(statusPath)),
  );
  requiredChecks.push(
    check("Material download route", fs.existsSync(routePath)),
  );
  requiredChecks.push(
    check(
      "PG route import",
      count(routeSource, "@/lib/pg-download-policy") === 1,
      `count=${count(routeSource, "@/lib/pg-download-policy")}`,
    ),
  );
  requiredChecks.push(
    check(
      "PG route marker",
      count(routeSource, "DHARMA_PG_PAYMENT_DOWNLOAD_POLICY") === 1,
      `count=${count(routeSource, "DHARMA_PG_PAYMENT_DOWNLOAD_POLICY")}`,
    ),
  );
  requiredChecks.push(
    check(
      "Pre-approval mode is fail-closed",
      envValue(envSource, "DHARMA_PG_APPROVED").toLowerCase() === "false",
    ),
  );
  requiredChecks.push(
    check(
      "Test purchase is disabled",
      envValue(envSource, "DHARMA_TEST_PURCHASE_ENABLED").toLowerCase() ===
        "false",
    ),
  );

  const oldMarkerPattern =
    /DHARMA_OWNER_DOWNLOAD_LOCK|DHARMA_MOBILE_DOWNLOAD_BLOCK|DHARMA_DOWNLOAD_AUTH_GATE|DHARMA_DOWNLOAD_ACCESS_CODE_GATE|enforceDharmaDownloadAccess|blockMobileMaterialDownload|requireDownloadAuthorization/i;
  requiredChecks.push(
    check("Old owner/mobile gate removed from download route", !oldMarkerPattern.test(routeSource)),
  );

  if (fs.existsSync(testRoutePath)) {
    requiredChecks.push(
      check(
        "Test purchase API is guarded",
        testRouteSource.includes("DHARMA_DISABLE_TEST_PURCHASE") &&
          testRouteSource.includes("enforceTestPurchasePolicy"),
      ),
    );
  } else {
    console.log("INFO  Test purchase API does not exist.");
  }

  const hasPaymentEvidence = paymentEvidence(routeSource);
  check(
    "Existing payment/purchase verification evidence",
    hasPaymentEvidence,
    hasPaymentEvidence
      ? "found"
      : "not found; do not set DHARMA_PG_APPROVED=true until the download route is reviewed",
  );

  const failed = requiredChecks.some((value) => !value);
  if (failed) {
    console.error("");
    console.error("Verification failed. Fix the FAIL items before deployment.");
    process.exitCode = 1;
    return;
  }

  if (args.build) {
    console.log("");
    console.log("Running production build...");
    const result = spawnSync("npm.cmd", ["run", "build"], {
      cwd: projectRoot,
      stdio: "inherit",
      shell: true,
    });
    if (result.status !== 0) {
      process.exitCode = result.status || 1;
      return;
    }
  }

  console.log("");
  console.log("Verification completed.");
  console.log(
    hasPaymentEvidence
      ? "The route still contains payment/purchase verification indicators."
      : "WARNING: Payment verification was not detected automatically.",
  );
}

try {
  main();
} catch (error) {
  console.error(
    error instanceof Error ? `ERROR: ${error.message}` : `ERROR: ${String(error)}`,
  );
  process.exitCode = 1;
}

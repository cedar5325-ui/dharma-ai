﻿@echo off
setlocal
chcp 65001 >nul
echo.
echo DHARMA AI PG/payment policy verification V3
echo.
node "%~dp0VERIFY_PG_PAYMENT_DOWNLOAD_POLICY_V3.mjs" --build
set "EXIT_CODE=%ERRORLEVEL%"
echo.
pause
exit /b %EXIT_CODE%

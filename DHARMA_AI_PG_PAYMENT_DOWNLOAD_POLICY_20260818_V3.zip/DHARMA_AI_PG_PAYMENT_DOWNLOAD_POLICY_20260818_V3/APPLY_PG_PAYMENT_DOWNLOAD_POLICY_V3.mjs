import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const DOWNLOAD_MARKER = "DHARMA_PG_PAYMENT_DOWNLOAD_POLICY";
const TEST_MARKER = "DHARMA_DISABLE_TEST_PURCHASE";

function parseArgs(argv) {
  const result = {};
  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index];
    if (item === "--project" && argv[index + 1]) {
      result.project = argv[index + 1];
      index += 1;
    }
  }
  return result;
}

function locateProjectRoot(candidate) {
  const starts = [candidate, process.cwd(), SCRIPT_DIR].filter(Boolean);

  for (const start of starts) {
    let current = path.resolve(start);
    for (let depth = 0; depth < 10; depth += 1) {
      if (fs.existsSync(path.join(current, "package.json"))) {
        return current;
      }
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
  }

  throw new Error(
    "Could not locate the DHARMA project folder containing package.json.",
  );
}

function timestamp() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate()),
    "_",
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds()),
  ].join("");
}

function ensureParent(filePath) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
}

function backupFile(filePath) {
  if (!fs.existsSync(filePath)) return null;
  const backupPath = `${filePath}.backup_${timestamp()}`;
  fs.copyFileSync(filePath, backupPath);
  console.log(`Backup: ${backupPath}`);
  return backupPath;
}

function writeText(filePath, content) {
  ensureParent(filePath);
  fs.writeFileSync(filePath, content.replace(/\r?\n/g, "\r\n"), "utf8");
}

function copyPatchFile(relativePath, projectRoot) {
  const source = path.join(SCRIPT_DIR, relativePath);
  const target = path.join(projectRoot, relativePath);

  if (!fs.existsSync(source)) {
    throw new Error(`Patch source file not found: ${source}`);
  }

  if (fs.existsSync(target)) backupFile(target);
  ensureParent(target);
  fs.copyFileSync(source, target);
  console.log(`Installed: ${target}`);
}

const LEGACY_ENV_NAMES = new Set([
  "DHARMA_PUBLIC_DOWNLOAD_ENABLED",
  "DHARMA_OWNER_DOWNLOAD_CODE",
  "DHARMA_OWNER_DOWNLOAD_TOKEN_SECRET",
  "DHARMA_OWNER_DOWNLOAD_SESSION_HOURS",
  "DHARMA_MOBILE_DOWNLOAD_ENABLED",
  "DHARMA_DOWNLOAD_AUTH_REQUIRED",
  "DHARMA_DOWNLOAD_AUTH_NUMBER",
  "DHARMA_DOWNLOAD_SESSION_SECRET",
  "DHARMA_DOWNLOAD_AUTH_TTL_MINUTES",
  "DHARMA_DOWNLOAD_ACCESS_REQUIRED",
  "DHARMA_DOWNLOAD_ACCESS_CODE",
  "DHARMA_DOWNLOAD_ACCESS_SECRET",
  "DHARMA_DOWNLOAD_ACCESS_TTL_HOURS",
  "DHARMA_PG_APPROVED",
  "DHARMA_TEST_PURCHASE_ENABLED",
]);

function updateEnvFile(envPath) {
  if (fs.existsSync(envPath)) backupFile(envPath);

  const source = fs.existsSync(envPath)
    ? fs.readFileSync(envPath, "utf8")
    : "";

  const keptLines = source
    .split(/\r?\n/)
    .filter((line) => {
      const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=/);
      return !match || !LEGACY_ENV_NAMES.has(match[1]);
    });

  while (keptLines.length > 0 && keptLines.at(-1) === "") {
    keptLines.pop();
  }

  if (keptLines.length > 0) keptLines.push("");
  keptLines.push(
    "# DHARMA PG/payment download policy",
    "DHARMA_PG_APPROVED=false",
    "DHARMA_TEST_PURCHASE_ENABLED=false",
    "",
  );

  writeText(envPath, keptLines.join("\n"));
  console.log(`Updated: ${envPath}`);
}

function updateGitignore(gitignorePath) {
  const source = fs.existsSync(gitignorePath)
    ? fs.readFileSync(gitignorePath, "utf8")
    : "";

  const lines = source.split(/\r?\n/);
  const needed = [
    ".env.local",
    ".env.local.backup_*",
    "*.backup_*",
    "DHARMA_AI_*_PG_*.zip",
    "DHARMA_AI_*_PG_*.sha256",
  ];
  let changed = false;

  for (const entry of needed) {
    if (!lines.some((line) => line.trim() === entry)) {
      lines.push(entry);
      changed = true;
    }
  }

  if (changed) {
    if (fs.existsSync(gitignorePath)) backupFile(gitignorePath);
    writeText(gitignorePath, `${lines.join("\n").replace(/\n+$/, "")}\n`);
    console.log(`Updated: ${gitignorePath}`);
  }
}

function removeImportFromModule(source, modulePath) {
  const escaped = modulePath.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const importPattern = new RegExp(
    `^\\s*import[^\\r\\n]*\\s+from\\s+["']${escaped}["'];?\\s*\\r?\\n`,
    "gm",
  );
  return source.replace(importPattern, "");
}

function removeLegacyImports(source) {
  const modules = [
    "@/lib/download-access-guard",
    "@/lib/mobile-download-guard",
    "@/lib/download-authorization",
    "@/lib/download-access-gate",
    "@/lib/pg-download-policy",
  ];

  let updated = source;
  for (const modulePath of modules) {
    updated = removeImportFromModule(updated, modulePath);
  }
  return updated;
}

function removeMarkerBlock(source, marker) {
  const escaped = marker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pattern = new RegExp(
    `\\r?\\n?\\s*//\\s*${escaped}[^\\r\\n]*\\r?\\n` +
      `(?:\\s*(?:const|let)\\s+[^\\r\\n;]+(?:;|\\r?\\n)\\s*)?` +
      `(?:[ \\t]*if[ \\t]*\\([^\\r\\n]+\\)[ \\t]*return[ \\t]+[^;\\r\\n]+;?[ \\t]*(?:\\r?\\n)?)?`,
    "g",
  );
  return source.replace(pattern, "\n");
}

function removeLegacyGuardLines(source) {
  let updated = source;

  const markers = [
    "DHARMA_OWNER_DOWNLOAD_LOCK",
    "DHARMA_MOBILE_DOWNLOAD_BLOCK",
    "DHARMA_DOWNLOAD_AUTH_GATE",
    "DHARMA_DOWNLOAD_ACCESS_CODE_GATE",
    "DHARMA_PG_PAYMENT_DOWNLOAD_POLICY",
    "DHARMA_DISABLE_TEST_PURCHASE",
  ];

  for (const marker of markers) {
    updated = removeMarkerBlock(updated, marker);
  }

  const variableNames = [
    "dharmaDownloadAccess",
    "dharmaMobileDownloadBlock",
    "dharmaDownloadAuthorization",
    "dharmaDownloadAccessGate",
    "dharmaPgPolicyBlock",
    "dharmaTestPurchaseBlock",
  ];

  for (const variableName of variableNames) {
    const escaped = variableName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    updated = updated.replace(
      new RegExp(
        `^\\s*(?:const|let)\\s+${escaped}\\s*=\\s*[^;]+;\\s*$`,
        "gm",
      ),
      "",
    );
    updated = updated.replace(
      new RegExp(
        `^\\s*if\\s*\\(\\s*${escaped}\\s*\\)\\s*return\\s+${escaped};?\\s*$`,
        "gm",
      ),
      "",
    );
  }

  return updated.replace(/\n{3,}/g, "\n\n");
}

function addImportAfterDirective(source, importLine) {
  if (source.includes(importLine)) return source;

  const directive = source.match(
    /^\s*(["']use (?:server|client)["'];?\s*\r?\n)/,
  );

  if (directive) {
    const index = directive[0].length;
    return `${source.slice(0, index)}${importLine}\n${source.slice(index)}`;
  }

  return `${importLine}\n${source}`;
}

function findHandler(source, allowedNames) {
  const names = allowedNames.join("|");
  const functionPattern = new RegExp(
    `export\\s+(?:async\\s+)?function\\s+(?:${names})\\s*\\(\\s*([A-Za-z_$][A-Za-z0-9_$]*)[\\s\\S]*?\\)\\s*(?::\\s*[^\\{]+)?\\{`,
    "m",
  );
  const functionMatch = functionPattern.exec(source);
  if (functionMatch) {
    return {
      index: functionMatch.index + functionMatch[0].length,
      requestParam: functionMatch[1],
    };
  }

  const arrowPattern = new RegExp(
    `export\\s+const\\s+(?:${names})\\s*=\\s*(?:async\\s*)?\\(\\s*([A-Za-z_$][A-Za-z0-9_$]*)[\\s\\S]*?\\)\\s*(?::\\s*[^=]+)?=>\\s*\\{`,
    "m",
  );
  const arrowMatch = arrowPattern.exec(source);
  if (arrowMatch) {
    return {
      index: arrowMatch.index + arrowMatch[0].length,
      requestParam: arrowMatch[1],
    };
  }

  return null;
}

function insertGuard(source, marker, functionName, variableName, allowedNames) {
  if (source.includes(marker)) return source;

  const handler = findHandler(source, allowedNames);
  if (!handler) {
    throw new Error(
      `Could not find an exported ${allowedNames.join("/")} handler.`,
    );
  }

  const block =
    `\n  // ${marker}\n` +
    `  const ${variableName} = ${functionName}(${handler.requestParam});\n` +
    `  if (${variableName}) return ${variableName};\n`;

  return `${source.slice(0, handler.index)}${block}${source.slice(handler.index)}`;
}

function patchDownloadRoute(routePath) {
  const original = fs.readFileSync(routePath, "utf8");
  let updated = removeLegacyImports(original);
  updated = removeLegacyGuardLines(updated);
  updated = addImportAfterDirective(
    updated,
    'import { enforcePgApprovalBeforeDownload } from "@/lib/pg-download-policy";',
  );
  updated = insertGuard(
    updated,
    DOWNLOAD_MARKER,
    "enforcePgApprovalBeforeDownload",
    "dharmaPgPolicyBlock",
    ["GET", "POST"],
  );

  if (updated !== original) {
    backupFile(routePath);
    writeText(routePath, updated);
    console.log(`Patched: ${routePath}`);
  } else {
    console.log(`Already patched: ${routePath}`);
  }
}

function patchTestPurchaseRoute(routePath) {
  if (!fs.existsSync(routePath)) {
    console.log("Test purchase route was not found. Nothing to disable.");
    return;
  }

  const original = fs.readFileSync(routePath, "utf8");
  let updated = removeImportFromModule(original, "@/lib/pg-download-policy");
  updated = removeMarkerBlock(updated, TEST_MARKER);
  updated = updated.replace(
    /^\s*(?:const|let)\s+dharmaTestPurchaseBlock\s*=\s*[^;]+;\s*$/gm,
    "",
  );
  updated = updated.replace(
    /^\s*if\s*\(\s*dharmaTestPurchaseBlock\s*\)\s*return\s+dharmaTestPurchaseBlock;?\s*$/gm,
    "",
  );
  updated = addImportAfterDirective(
    updated,
    'import { enforceTestPurchasePolicy } from "@/lib/pg-download-policy";',
  );
  updated = insertGuard(
    updated,
    TEST_MARKER,
    "enforceTestPurchasePolicy",
    "dharmaTestPurchaseBlock",
    ["POST", "GET"],
  );

  if (updated !== original) {
    backupFile(routePath);
    writeText(routePath, updated);
    console.log(`Patched: ${routePath}`);
  } else {
    console.log(`Already patched: ${routePath}`);
  }
}

const legacyFiles = [
  {
    relative: "src/lib/download-access-guard.ts",
    markers: ["dharma_owner_download", "DHARMA_OWNER_DOWNLOAD_CODE"],
  },
  {
    relative: "src/lib/mobile-download-guard.ts",
    markers: ["blockMobileMaterialDownload", "DHARMA_MOBILE_DOWNLOAD_ENABLED"],
  },
  {
    relative: "src/lib/download-authorization.ts",
    markers: ["DOWNLOAD_AUTH_COOKIE_NAME", "DHARMA_DOWNLOAD_AUTH_REQUIRED"],
  },
  {
    relative: "src/lib/download-access-gate.ts",
    markers: ["DHARMA_DOWNLOAD_ACCESS_REQUIRED", "download-access"],
  },
  {
    relative: "src/app/admin/download-access/page.tsx",
    markers: ["OwnerDownloadAccessPage", "운영자 자료 다운로드 인증"],
  },
  {
    relative: "src/app/api/admin/download-access/unlock/route.ts",
    markers: ["createOwnerDownloadToken", "OWNER_DOWNLOAD_AUTH_NOT_CONFIGURED"],
  },
  {
    relative: "src/app/api/admin/download-access/lock/route.ts",
    markers: ["clearOwnerDownloadCookie", "운영자 자료 다운로드 권한"],
  },
  {
    relative: "src/app/download-auth/page.tsx",
    markers: ["download-auth", "다운로드 인증"],
  },
  {
    relative: "src/app/api/download-auth/verify/route.ts",
    markers: ["verifyDownloadAuthNumber", "DOWNLOAD_AUTH"],
  },
  {
    relative: "src/app/api/download-auth/logout/route.ts",
    markers: ["clearDownloadAuthorizationCookie", "download-auth"],
  },
  {
    relative: "src/app/download-access/route.ts",
    markers: ["DHARMA_DOWNLOAD_ACCESS", "download-access"],
  },
];

function removeLegacyFiles(projectRoot) {
  for (const item of legacyFiles) {
    const filePath = path.join(projectRoot, item.relative);
    if (!fs.existsSync(filePath)) continue;

    const content = fs.readFileSync(filePath, "utf8");
    if (!item.markers.some((marker) => content.includes(marker))) {
      console.log(`Kept unrelated file: ${filePath}`);
      continue;
    }

    backupFile(filePath);
    fs.unlinkSync(filePath);
    console.log(`Removed obsolete owner/test gate file: ${filePath}`);
  }
}

function removeNextCache(projectRoot) {
  const nextPath = path.join(projectRoot, ".next");
  if (fs.existsSync(nextPath)) {
    fs.rmSync(nextPath, { recursive: true, force: true });
    console.log("Removed .next cache.");
  }
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const projectRoot = locateProjectRoot(args.project);

  console.log("");
  console.log("DHARMA AI PG/payment download policy patch V3");
  console.log(`Project: ${projectRoot}`);
  console.log("");

  const packageJson = path.join(projectRoot, "package.json");
  const downloadRoute = path.join(
    projectRoot,
    "src",
    "app",
    "api",
    "materials",
    "[id]",
    "download",
    "route.ts",
  );

  if (!fs.existsSync(packageJson)) {
    throw new Error(`package.json not found: ${packageJson}`);
  }
  if (!fs.existsSync(downloadRoute)) {
    throw new Error(`Material download route not found: ${downloadRoute}`);
  }

  updateEnvFile(path.join(projectRoot, ".env.local"));
  updateGitignore(path.join(projectRoot, ".gitignore"));

  copyPatchFile("src/lib/pg-download-policy.ts", projectRoot);
  copyPatchFile(
    "src/app/api/system/download-policy/route.ts",
    projectRoot,
  );

  patchDownloadRoute(downloadRoute);

  patchTestPurchaseRoute(
    path.join(
      projectRoot,
      "src",
      "app",
      "api",
      "purchases",
      "test-complete",
      "route.ts",
    ),
  );

  removeLegacyFiles(projectRoot);
  removeNextCache(projectRoot);

  console.log("");
  console.log("Patch completed.");
  console.log("- Before PG approval: all downloads are blocked on mobile and PC.");
  console.log("- After PG approval: the existing payment/purchase check remains mandatory.");
  console.log("- Owner-code bypass has been removed.");
  console.log("- Production test-purchase completion is disabled.");
  console.log("");
  console.log("Next:");
  console.log(`cd "${projectRoot}"`);
  console.log("npm.cmd run build");
  console.log("npm.cmd run dev");
  console.log("");
  console.log("Policy status: http://localhost:3000/api/system/download-policy");
}

try {
  main();
} catch (error) {
  console.error("");
  console.error(
    error instanceof Error ? `ERROR: ${error.message}` : `ERROR: ${String(error)}`,
  );
  process.exitCode = 1;
}

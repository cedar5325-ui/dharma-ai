param(
  [string]$ProjectRoot = "C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC"
)

$checks = @(
  @{ Name = "package.json"; Path = (Join-Path $ProjectRoot "package.json") },
  @{ Name = "관리자 로그인 페이지"; Path = (Join-Path $ProjectRoot "src\app\admin-login\page.tsx") },
  @{ Name = "관리자 로그인 API"; Path = (Join-Path $ProjectRoot "src\app\api\admin\login\route.ts") }
)

Write-Host "DHARMA AI 관리자 로그인 점검" -ForegroundColor Cyan
foreach ($check in $checks) {
  $exists = Test-Path -LiteralPath $check.Path
  $color = if ($exists) { "Green" } else { "Red" }
  Write-Host ("{0}: {1}" -f $check.Name, $exists) -ForegroundColor $color
  Write-Host ("  {0}" -f $check.Path)
}

Write-Host ""
Write-Host "포트 3000 사용 여부:" -ForegroundColor Cyan
Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue |
  Select-Object LocalAddress, LocalPort, OwningProcess |
  Format-Table -AutoSize

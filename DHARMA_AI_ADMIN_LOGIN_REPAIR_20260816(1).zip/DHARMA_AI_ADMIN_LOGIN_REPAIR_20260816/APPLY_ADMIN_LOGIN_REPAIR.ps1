param(
  [string]$ProjectRoot = "C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC"
)

$ErrorActionPreference = "Stop"
$SourceFile = Join-Path $PSScriptRoot "src\app\admin-login\page.tsx"
$TargetDir = Join-Path $ProjectRoot "src\app\admin-login"
$TargetFile = Join-Path $TargetDir "page.tsx"

Write-Host ""
Write-Host "DHARMA AI 관리자 로그인 복구를 시작합니다." -ForegroundColor Cyan
Write-Host "프로젝트: $ProjectRoot"

if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "package.json"))) {
  throw "package.json을 찾지 못했습니다. ProjectRoot 경로를 확인해 주세요."
}

New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null

if (Test-Path -LiteralPath $TargetFile) {
  $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
  $backup = "$TargetFile.backup_$stamp"
  Copy-Item -LiteralPath $TargetFile -Destination $backup -Force
  Write-Host "기존 파일 백업: $backup" -ForegroundColor Yellow
}

Copy-Item -LiteralPath $SourceFile -Destination $TargetFile -Force
Write-Host "관리자 로그인 페이지 복구 완료: $TargetFile" -ForegroundColor Green

$NextDir = Join-Path $ProjectRoot ".next"
if (Test-Path -LiteralPath $NextDir) {
  Remove-Item -LiteralPath $NextDir -Recurse -Force
  Write-Host ".next 캐시 삭제 완료" -ForegroundColor Green
}

$ApiRoute = Join-Path $ProjectRoot "src\app\api\admin\login\route.ts"
if (Test-Path -LiteralPath $ApiRoute) {
  Write-Host "관리자 로그인 API 확인 완료" -ForegroundColor Green
} else {
  Write-Host "주의: src\app\api\admin\login\route.ts 파일이 없습니다." -ForegroundColor Red
  Write-Host "페이지는 열려도 로그인이 처리되지 않을 수 있습니다."
}

Write-Host ""
Write-Host "이제 VS Code 터미널에서 아래 명령을 실행하세요." -ForegroundColor Cyan
Write-Host "cd `"$ProjectRoot`""
Write-Host "npm.cmd run dev"
Write-Host ""
Write-Host "Ready가 뜬 뒤 접속: http://localhost:3000/admin-login" -ForegroundColor Green

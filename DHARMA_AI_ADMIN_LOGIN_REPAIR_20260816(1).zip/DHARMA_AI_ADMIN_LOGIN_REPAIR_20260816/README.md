# DHARMA AI 관리자 로그인 페이지 복구 패치

## 해결하는 문제

- `http://localhost:3000/admin-login`이 404 또는 빈 화면으로 열리는 문제
- `useSearchParams() should be wrapped in a suspense boundary` 오류
- 최근 파일 교체 후 `src/app/admin-login/page.tsx`가 사라진 경우
- 오래된 `.next` 캐시 때문에 라우트가 반영되지 않는 경우

## 적용 순서

1. 실행 중인 개발 서버에서 `Ctrl + C`를 누릅니다.
2. `APPLY_ADMIN_LOGIN_REPAIR.ps1`을 PowerShell로 실행합니다.
3. VS Code 터미널에서 다음을 실행합니다.

```powershell
cd "C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC"
npm.cmd run dev
```

4. 터미널에 `Ready`가 표시된 다음 아래 주소를 엽니다.

```text
http://localhost:3000/admin-login
```

## 환경변수 확인

프로젝트의 `.env.local`에 관리자 비밀번호가 있어야 실제 로그인이 됩니다.

```env
ADMIN_PASSWORD=사용할_관리자_비밀번호
```

환경변수를 수정한 뒤에는 개발 서버를 종료하고 다시 실행합니다.

## 추가 점검

`CHECK_ADMIN_LOGIN.ps1`을 실행하면 페이지 파일, API 파일, 3000번 포트 상태를 확인합니다.

import fs from "node:fs";
import path from "node:path";

const root = path.resolve(process.argv[2] || process.cwd());
const file = path.join(root, "src", "app", "payment", "page.tsx");
const s = fs.readFileSync(file, "utf8");

const checks = [
  ["Toss SDK", 'https://js.tosspayments.com/v2/standard'],
  ["TEST client key", "NEXT_PUBLIC_TOSS_CLIENT_KEY"],
  ["CARD method", 'method: "CARD"'],
  ["success URL", "/payment/success"],
  ["fail URL", "/payment/fail"],
  ["purchase API", "/api/purchases/"],
  ["payment button", "카드로 결제하기"],
];

let ok = true;
for (const [name, needle] of checks) {
  const pass = s.includes(needle);
  console.log(`${pass ? "OK" : "FAIL"} - ${name}`);
  if (!pass) ok = false;
}

if (!ok) process.exit(1);
console.log("Verification passed.");

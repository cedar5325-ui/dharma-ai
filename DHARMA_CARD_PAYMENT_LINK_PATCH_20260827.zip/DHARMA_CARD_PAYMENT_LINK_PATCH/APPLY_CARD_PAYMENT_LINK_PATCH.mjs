import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(process.argv[2] || process.cwd());
const target = path.join(root, "src", "app", "payment", "page.tsx");
const source = path.join(scriptDir, "files", "payment-page.tsx");

if (!fs.existsSync(target)) throw new Error("src/app/payment/page.tsx를 찾지 못했습니다.");

const d = new Date();
const z = (v) => String(v).padStart(2, "0");
const stamp = `${d.getFullYear()}${z(d.getMonth()+1)}${z(d.getDate())}_${z(d.getHours())}${z(d.getMinutes())}${z(d.getSeconds())}`;
const backup = `${target}.backup_${stamp}`;
fs.copyFileSync(target, backup);
console.log(`Backup: ${backup}`);

fs.copyFileSync(source, target);
console.log("Patched: src/app/payment/page.tsx");

const nextDir = path.join(root, ".next");
if (fs.existsSync(nextDir)) {
  fs.rmSync(nextDir, { recursive: true, force: true });
  console.log("Removed .next cache.");
}

console.log("");
console.log("Card payment -> Toss Payments link patch completed.");
console.log("Next: npm.cmd run build");

DHARMA AI 카드결제 → Toss Payments 연결 패치

동작:
자료 선택 → 구매요청 생성 → /payment → '카드로 결제하기' 클릭 → Toss Payments 카드 결제창

필수 Vercel 환경변수:
NEXT_PUBLIC_TOSS_CLIENT_KEY = Toss TEST 클라이언트 키
TOSS_SECRET_KEY = 같은 TEST 환경의 시크릿 키

PG 승인 전에는 TEST 키만 사용하세요.
DHARMA_PG_APPROVED=false는 그대로 유지합니다.

적용:
node APPLY_CARD_PAYMENT_LINK_PATCH.mjs "C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC"

검증:
node VERIFY_CARD_PAYMENT_LINK_PATCH.mjs "C:\Users\82105\Desktop\2026년 신규사업\DHARMA_AI_v4_RC"

빌드:
npm.cmd run build

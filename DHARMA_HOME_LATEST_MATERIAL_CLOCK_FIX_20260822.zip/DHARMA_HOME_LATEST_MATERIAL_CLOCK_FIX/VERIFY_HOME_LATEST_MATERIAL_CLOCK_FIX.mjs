import fs from "node:fs";
import path from "node:path";

const root = path.resolve(process.argv[2] || process.cwd());
const file = path.join(root, "src", "app", "page.tsx");
const s = fs.readFileSync(file, "utf8");

const checks = [
  ["React hooks", 'import { useEffect, useState } from "react";'],
  ["latest material API", 'fetch("/api/system/latest-material-upload"'],
  ["lastUploadAt", "json?.lastUploadAt"],
  ["60s refresh", "60_000"],
  ["label", "LAST MATERIAL UPDATE"],
];

let ok = true;
for (const [name, needle] of checks) {
  const pass = s.includes(needle);
  console.log(`${pass ? "OK" : "FAIL"} - ${name}`);
  if (!pass) ok = false;
}
if (!ok) process.exit(1);
console.log("Verification passed.");

import fs from "node:fs";
import path from "node:path";

const root = path.resolve(process.argv[2] || process.cwd());
const file = path.join(root, "src", "app", "page.tsx");

if (!fs.existsSync(file)) throw new Error("src/app/page.tsx를 찾지 못했습니다.");

const d = new Date();
const z = (v) => String(v).padStart(2, "0");
const stamp = `${d.getFullYear()}${z(d.getMonth()+1)}${z(d.getDate())}_${z(d.getHours())}${z(d.getMinutes())}${z(d.getSeconds())}`;
const backup = `${file}.backup_${stamp}`;
fs.copyFileSync(file, backup);
console.log(`Backup: ${backup}`);

let s = fs.readFileSync(file, "utf8");

if (!s.includes('import { useEffect, useState } from "react";')) {
  s = s.replace('"use client";', '"use client";\n\nimport { useEffect, useState } from "react";');
}

const pattern = /function DigitalUpgradeClock\(\) \{[\s\S]*?\n\}\n\nexport default function HomePage\(\)/m;
if (!pattern.test(s)) throw new Error("DigitalUpgradeClock 함수 구간을 찾지 못했습니다.");

const replacement = `function DigitalUpgradeClock() {
  const fallbackRaw =
    process.env.NEXT_PUBLIC_DHARMA_LAST_UPGRADE_AT ||
    FALLBACK_LAST_UPGRADE_AT;

  const [raw, setRaw] = useState(fallbackRaw);

  useEffect(() => {
    let cancelled = false;

    async function loadLatestMaterialTime() {
      try {
        const response = await fetch("/api/system/latest-material-upload", {
          cache: "no-store",
        });
        const json = await response.json();

        if (!cancelled && response.ok && json?.ok && json?.lastUploadAt) {
          setRaw(String(json.lastUploadAt));
        }
      } catch {
        // API 실패 시 fallback 값을 유지합니다.
      }
    }

    loadLatestMaterialTime();
    const timer = window.setInterval(loadLatestMaterialTime, 60_000);

    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, []);

  const display = formatKstDateTime(raw);

  return (
    <aside className="upgradeClock" aria-label="다르마 자료 마지막 업데이트 시각">
      <div className="upgradeClockTop">
        <span className="upgradeDot" aria-hidden="true" />
        <span>LAST MATERIAL UPDATE</span>
      </div>
      <time className="upgradeDigits" dateTime={raw}>
        <span className="upgradeDate">{display.date}</span>
        <span className="upgradeTime">{display.time}</span>
        <span className="upgradeZone">KST</span>
      </time>
      <small>DHARMA MATERIALS UPDATED</small>
    </aside>
  );
}

export default function HomePage()`;

s = s.replace(pattern, replacement);
fs.writeFileSync(file, s, "utf8");

const nextDir = path.join(root, ".next");
if (fs.existsSync(nextDir)) {
  fs.rmSync(nextDir, { recursive: true, force: true });
  console.log("Removed .next cache.");
}

console.log("Patched: src/app/page.tsx");
console.log("Homepage latest-material clock fix completed.");
console.log("Next: npm.cmd run build");

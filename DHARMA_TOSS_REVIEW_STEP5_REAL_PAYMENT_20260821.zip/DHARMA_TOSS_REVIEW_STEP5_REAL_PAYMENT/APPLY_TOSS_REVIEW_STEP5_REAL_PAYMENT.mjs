import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.join(SCRIPT_DIR, "files");

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--project" && argv[i + 1]) out.project = argv[++i];
  }
  return out;
}

function findRoot(candidate) {
  const starts = [candidate, process.cwd(), SCRIPT_DIR].filter(Boolean);
  for (const start of starts) {
    let p = path.resolve(start);
    for (let i = 0; i < 10; i++) {
      if (fs.existsSync(path.join(p, "package.json"))) return p;
      const parent = path.dirname(p);
      if (parent === p) break;
      p = parent;
    }
  }
  throw new Error("프로젝트 루트를 찾지 못했습니다.");
}

function stamp() {
  const d = new Date();
  const z = v => String(v).padStart(2, "0");
  return `${d.getFullYear()}${z(d.getMonth()+1)}${z(d.getDate())}_${z(d.getHours())}${z(d.getMinutes())}${z(d.getSeconds())}`;
}

function backup(file) {
  if (!fs.existsSync(file)) return;
  const dest = `${file}.backup_${stamp()}`;
  fs.copyFileSync(file, dest);
  console.log(`Backup: ${dest}`);
}

function installFile(root, srcName, targetRel) {
  const target = path.join(root, ...targetRel.split("/"));
  fs.mkdirSync(path.dirname(target), { recursive: true });
  backup(target);
  fs.copyFileSync(path.join(SRC, srcName), target);
  console.log(`Patched: ${targetRel}`);
}

function patchMaterialDetail(root) {
  const target = path.join(root, "src", "app", "materials", "[id]", "page.tsx");
  if (!fs.existsSync(target)) throw new Error("materials/[id]/page.tsx가 없습니다.");
  backup(target);

  let s = fs.readFileSync(target, "utf8");

  // Replace the post-create local test state with redirect to real checkout.
  const pattern = /setPurchaseId\(json\.purchaseId[\s\S]{0,500}?setPaid\(false\);\s*setMessage\([\s\S]{0,250}?\);/m;

  if (!pattern.test(s)) {
    throw new Error(
      "상품 상세페이지의 createPurchase 완료 구간을 자동으로 찾지 못했습니다. 원본은 변경하지 않았습니다."
    );
  }

  s = s.replace(
    pattern,
    `const nextPurchaseId = json.purchaseId || json.purchase?.id || "";\n` +
    `      const nextPurchaseToken = json.purchaseToken || json.token || json.purchase?.purchaseToken || "";\n\n` +
    `      setPurchaseId(nextPurchaseId);\n` +
    `      setPurchaseToken(nextPurchaseToken);\n` +
    `      setPaid(false);\n\n` +
    `      if (!nextPurchaseId || !nextPurchaseToken) {\n` +
    `        throw new Error("결제 페이지 이동에 필요한 구매정보가 없습니다.");\n` +
    `      }\n\n` +
    `      window.location.href = \`/payment?purchaseId=\${encodeURIComponent(nextPurchaseId)}&token=\${encodeURIComponent(nextPurchaseToken)}\`;`
  );

  // Hide test payment button from public product detail.
  s = s.replace(
    /<button\s+style=\{primaryButton\}\s+onClick=\{completeTestPayment\}\s+disabled=\{!!busy \|\| !purchaseToken\}>[\s\S]*?<\/button>/m,
    `{process.env.NEXT_PUBLIC_DHARMA_SHOW_TEST_PAYMENT === "true" && (\n` +
    `            <button style={primaryButton} onClick={completeTestPayment} disabled={!!busy || !purchaseToken}>\n` +
    `              {busy === "pay" ? "처리 중..." : "테스트 결제 완료"}\n` +
    `            </button>\n` +
    `          )}`
  );

  fs.writeFileSync(target, s, "utf8");
  console.log("Patched: src/app/materials/[id]/page.tsx");
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const root = findRoot(args.project);

  installFile(root, "purchases-create-route.ts", "src/app/api/purchases/create/route.ts");
  installFile(root, "purchase-detail-route.ts", "src/app/api/purchases/[id]/route.ts");
  installFile(root, "payments-confirm-route.ts", "src/app/api/payments/confirm/route.ts");
  installFile(root, "payment-page.tsx", "src/app/payment/page.tsx");
  installFile(root, "payment-success-page.tsx", "src/app/payment/success/page.tsx");
  installFile(root, "payment-fail-page.tsx", "src/app/payment/fail/page.tsx");
  installFile(root, "toss-step5.sql", "supabase/toss_step5_real_payment.sql");

  patchMaterialDetail(root);

  const nextDir = path.join(root, ".next");
  if (fs.existsSync(nextDir)) {
    fs.rmSync(nextDir, { recursive: true, force: true });
    console.log("Removed .next cache.");
  }

  console.log("");
  console.log("STEP 5 real Toss payment patch completed.");
  console.log("IMPORTANT: Run supabase/toss_step5_real_payment.sql in Supabase SQL Editor BEFORE testing.");
  console.log("Then: npm.cmd run build");
}

try {
  main();
} catch (e) {
  console.error(`ERROR: ${e instanceof Error ? e.message : String(e)}`);
  process.exitCode = 1;
}

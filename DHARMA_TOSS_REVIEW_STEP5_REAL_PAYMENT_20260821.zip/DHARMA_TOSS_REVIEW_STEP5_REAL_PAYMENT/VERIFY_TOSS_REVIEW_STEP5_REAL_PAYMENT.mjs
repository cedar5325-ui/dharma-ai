import fs from "node:fs";
import path from "node:path";

const i = process.argv.indexOf("--project");
const root = path.resolve(i >= 0 ? process.argv[i + 1] : process.cwd());

const checks = [
  ["payment page", "src/app/payment/page.tsx", "https://js.tosspayments.com/v2/standard"],
  ["payment request", "src/app/payment/page.tsx", 'method: "CARD"'],
  ["server amount verify", "src/app/api/payments/confirm/route.ts", "storedAmount !== receivedAmount"],
  ["server confirm amount", "src/app/api/payments/confirm/route.ts", "amount: storedAmount"],
  ["paid update", "src/app/api/payments/confirm/route.ts", 'status: "paid"'],
  ["success confirm", "src/app/payment/success/page.tsx", 'fetch("/api/payments/confirm"'],
  ["purchase detail API", "src/app/api/purchases/[id]/route.ts", "toss_order_id"],
  ["SQL migration", "supabase/toss_step5_real_payment.sql", "toss_payment_key"],
  ["product redirect", "src/app/materials/[id]/page.tsx", "/payment?purchaseId="],
];

let ok = true;
for (const [name, rel, needle] of checks) {
  const file = path.join(root, ...rel.split("/"));
  const text = fs.existsSync(file) ? fs.readFileSync(file, "utf8") : "";
  const pass = text.includes(needle);
  console.log(`${pass ? "OK" : "FAIL"} - ${name}`);
  if (!pass) ok = false;
}
if (!ok) process.exit(1);
console.log("");
console.log("STEP 5 verification passed.");

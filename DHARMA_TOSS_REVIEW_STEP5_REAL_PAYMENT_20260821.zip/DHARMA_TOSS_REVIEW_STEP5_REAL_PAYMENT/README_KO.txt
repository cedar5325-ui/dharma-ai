DHARMA Toss Payments 심사 준비 - STEP 5 실제 결제창 연결

목표
실제 상품 → 구매요청(pending) → /payment → Toss Payments V2 카드 결제창
→ /payment/success → 서버 금액 검증 → Toss 승인 API
→ dharma_purchases.status=paid → 다운로드 권한

중요
1. Supabase SQL을 먼저 실행해야 합니다.
   supabase/toss_step5_real_payment.sql
2. Vercel 환경변수
   NEXT_PUBLIC_TOSS_CLIENT_KEY = Toss 클라이언트 키
   TOSS_SECRET_KEY = 같은 환경의 Toss 시크릿 키
   테스트 심사 중에는 test 키끼리, 운영 전환 시 live 키끼리 사용하세요.
3. TOSS_SECRET_KEY는 절대 NEXT_PUBLIC_ 접두어를 붙이지 마세요.
4. NEXT_PUBLIC_DHARMA_SHOW_TEST_PAYMENT 는 설정하지 않거나 false로 유지합니다.
5. DHARMA_PG_APPROVED=false 정책은 이번 패치가 변경하지 않습니다.
   즉, PG 승인 전 다운로드 차단 정책은 그대로 유지됩니다.
6. 30일 다운로드 만료의 실제 서버 강제는 STEP 6에서 적용합니다.

적용 순서
A. ZIP을 프로젝트 폴더에 풀기
B. 패치 실행
C. Supabase SQL Editor에서 SQL 실행
D. npm.cmd run build
E. 환경변수 설정 후 Vercel 배포
F. 테스트 상품으로 토스 결제창 확인

Git에는 키 파일이나 .env.local을 올리지 마세요.
